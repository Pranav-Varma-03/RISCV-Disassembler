x)the file cs21btech11044.cpp takes in hex values and gives out corresponding assembly code
x)input i.e., Hex values should be given inside the code [Static Input].
x)one can use : hexcode.push_back("<XXXXXXXX>"); in main function of program to add hex digit.
x)Compiling and execution :
	g++ cs21btech11044.cpp                (Enter)
	./a.out                               (Enter)
x)and one could see the deassembled code now for given set of inputs.